function z(){
			var a=localStorage.getItem("quant");
			var b=localStorage.getItem("total");
			document.getElementById("item").innerHTML=a;
			document.getElementById("total").innerHTML=b;
            document.getElementById("gtotal").innerHTML=b;
}